# Guida all'Aggiornamento

Istruzioni per passare alla versione v2.0 del modulo `dkp-native-blog-pro`:
- Esegui il backup dei dati precedenti.
- Sostituisci la vecchia cartella con questa versione.
- Avvia il processo di migrazione dal pannello admin.
