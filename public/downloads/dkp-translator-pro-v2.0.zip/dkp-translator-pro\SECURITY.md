# Policy di Sicurezza

La sicurezza è la nostra priorità. Questo modulo è certificato dal DKP Core.

## Segnalazioni
Se individui vulnerabilità, contatta immediatamente il supporto architetturale DevKernelPulse.
