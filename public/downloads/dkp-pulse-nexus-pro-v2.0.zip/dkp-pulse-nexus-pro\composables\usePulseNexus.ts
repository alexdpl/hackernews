// dkp-proprietary-plugins/dkp-pulse-nexus-pro/composables/usePulseNexus.ts
import { ref, computed } from 'vue'

export interface ChatMessage {
  id: string
  sender: string
  role: 'user' | 'assistant' | 'system'
  text: string
  xpEarned?: number
  timestamp: string
}

const isOpen = ref(false)
const messages = ref<any[]>([])
const userXp = ref(150) // XP base utente

export const usePulseNexus = () => {
  // Calcolo dinamico del Rank e del Colore Badge per l'interfaccia
  const currentRank = computed(() => {
    if (userXp.value >= 1000) return { name: 'Kernel Architect', color: '#a855f7' }
    if (userXp.value >= 500) return { name: 'Code Master', color: '#38bdf8' }
    return { name: 'Pulse Novice', color: '#00dc82' }
  })

  const loadHistory = async () => {
    try {
      const data = await $fetch('/api/nexus/history')
      if (Array.isArray(data)) {
        messages.value = data
      }
    } catch (err) {
      console.error('Errore nel caricamento della cronologia Pulse Nexus:', err)
    }
  }

  const toggleChat = () => {
    isOpen.value = !isOpen.value
    if (isOpen.value && messages.value.length === 0) {
      loadHistory()
    }
  }

  // RETURN FONDAMENTALE: Espone tutte le variabili al componente Vue
  return {
    isOpen,
    messages,
    userXp,
    currentRank,
    toggleChat,
    loadHistory
  }
}