// dkp-proprietary-plugins/dkp-pulse-nexus-pro/composables/usePulseGamification.ts
import { computed } from 'vue'

export interface UserRank {
  title: string
  badge: string
  color: string
  nextLevelXp: number
}

export const usePulseGamification = (userXp: Ref<number>) => {
  const currentRank = computed<UserRank>(() => {
    const xp = userXp.value
    const level = Math.floor(xp / 100) + 1

    if (level >= 20) {
      return { title: 'DKP Sentinel Master', badge: '👑', color: '#ffd700', nextLevelXp: level * 100 }
    } else if (level >= 10) {
      return { title: 'Cyber Architect', badge: '🔮', color: '#c084fc', nextLevelXp: level * 100 }
    } else if (level >= 5) {
      return { title: 'Code Craftsman', badge: '⚡', color: '#38bdf8', nextLevelXp: level * 100 }
    } else {
      return { title: 'Kernel Initiate', badge: '🟢', color: '#00dc82', nextLevelXp: level * 100 }
    }
  })

  return {
    currentRank
  }
}