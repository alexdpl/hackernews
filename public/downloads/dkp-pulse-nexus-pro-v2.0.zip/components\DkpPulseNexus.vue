<!-- dkp-proprietary-plugins/dkp-pulse-nexus-pro/components/DkpPulseNexus.vue -->
<template>
  <div v-if="isAuthenticated" class="pulse-nexus-wrapper">
    
    <!-- NOTIFICA FLOAT TOAST XP (Quando si guadagnano punti) -->
    <transition name="toast-anim">
      <div v-if="recentXpGained > 0" class="xp-toast-notification">
        🔥 +{{ recentXpGained }} XP Guadagnati!
      </div>
    </transition>

    <!-- PULSANTE FLOATING TOGGLE CON PROFILO XP -->
    <button @click="toggleChat" class="nexus-trigger-btn" :class="{ active: isOpen }">
      <div class="pulse-indicator"></div>
      <span class="btn-icon">{{ currentRank.badge }}</span>
      <div class="trigger-xp-info">
        <span class="rank-title">{{ currentRank.title }}</span>
        <span class="xp-badge" :style="{ borderColor: currentRank.color, color: currentRank.color }">
          {{ userXp }} XP (Lvl {{ userLevel }})
        </span>
      </div>
    </button>

    <!-- POPUP CHAT NEXUS GLASSMOPRHIC -->
    <transition name="fade-slide">
      <div v-if="isOpen" class="nexus-chat-window">
        
        <!-- HEADER WINDOW CON LIVELLO & AVANZAMENTO -->
        <div class="nexus-header">
          <div class="header-main">
            <div class="header-info">
              <span class="status-dot"></span>
              <strong>PULSE NEXUS AGENT</strong>
              <span class="rank-badge-pill" :style="{ backgroundColor: `${currentRank.color}22`, color: currentRank.color }">
                {{ currentRank.badge }} {{ currentRank.title }}
              </span>
            </div>
            <button @click="toggleChat" class="close-btn">✕</button>
          </div>

          <!-- BARRA AVANZAMENTO LIVELLO -->
          <div class="level-progress-container">
            <div class="level-labels">
              <span>Livello {{ userLevel }}</span>
              <span>{{ userXp % 100 }}/100 XP per il Prossimo Livello</span>
            </div>
            <div class="progress-track">
              <div 
                class="progress-fill" 
                :style="{ width: `${levelProgress}%`, backgroundColor: currentRank.color }"
              ></div>
            </div>
          </div>
        </div>

        <!-- AREA MESSAGGI CON SCROLL AUTOMATICO -->
        <div ref="messagesContainer" class="nexus-messages">
          
          <div v-if="isLoading" class="loading-state">
            <span class="spinner">⚡</span> Caricamento storico dal Kernel Neon DB...
          </div>

          <div 
            v-for="msg in messages" 
            :key="msg.id" 
            class="message-bubble"
            :class="msg.role"
          >
            <div class="message-meta">
              <span class="sender-name">{{ msg.sender }}</span>
              <span class="msg-time">{{ msg.timestamp }}</span>
            </div>
            <div class="message-text">
              {{ msg.text }}
            </div>
            <div v-if="msg.xpEarned" class="xp-reward-pill" :style="{ color: currentRank.color }">
              {{ currentRank.badge }} +{{ msg.xpEarned }} XP Riconosciuti
            </div>
          </div>
        </div>

        <!-- INPUT BAR CON TASTO INVIO -->
        <div class="nexus-input-bar">
          <input 
            v-model="inputQuery" 
            @keyup.enter="handleSend"
            type="text" 
            placeholder="Chiedi a Pulse o comunica con i dev..."
            class="nexus-input"
            :disabled="isSending"
          />
          <button @click="handleSend" class="send-btn" :disabled="isSending || !inputQuery.trim()">
            <span v-if="!isSending">➔</span>
            <span v-else class="spinner">⏳</span>
          </button>
        </div>

      </div>
    </transition>

  </div>
</template>

<script setup lang="ts">
import { ref, computed, watch, nextTick } from 'vue'

const { isOpen, messages, userXp, isLoading, toggleChat, sendNexusMessage } = usePulseNexus()
const { currentRank } = usePulseGamification(userXp)

const inputQuery = ref('')
const isSending = ref(false)
const recentXpGained = ref(0)
const messagesContainer = ref<HTMLElement | null>(null)

// Verifichiamo lo stato autenticato dal cookie dkp_session
const sessionCookie = useCookie('dkp_session')
const isAuthenticated = computed(() => !!sessionCookie.value)

// Calcolo Livello e Avanzamento %
const userLevel = computed(() => Math.floor(userXp.value / 100) + 1)
const levelProgress = computed(() => userXp.value % 100)

// Scroll Automatico verso il basso
const scrollToBottom = async () => {
  await nextTick()
  if (messagesContainer.value) {
    messagesContainer.value.scrollTop = messagesContainer.value.scrollHeight
  }
}

watch(messages, () => {
  scrollToBottom()
}, { deep: true })

const handleSend = async () => {
  const text = inputQuery.value.trim()
  if (!text || isSending.value) return

  isSending.value = true
  inputQuery.value = ''

  const oldXp = userXp.value
  await sendNexusMessage(text)
  const gained = userXp.value - oldXp

  if (gained > 0) {
    recentXpGained.value = gained
    setTimeout(() => {
      recentXpGained.value = 0
    }, 3000)
  }

  isSending.value = false
  scrollToBottom()
}
</script>

<style scoped>
.pulse-nexus-wrapper {
  position: fixed;
  bottom: 24px;
  right: 24px;
  z-index: 9999;
  font-family: system-ui, -apple-system, sans-serif;
}

/* XP TOAST NOTIFICATION */
.xp-toast-notification {
  position: absolute;
  top: -45px;
  right: 0;
  background: rgba(0, 220, 130, 0.95);
  color: #020420;
  font-weight: 900;
  font-size: 0.8rem;
  padding: 0.45rem 0.9rem;
  border-radius: 999px;
  box-shadow: 0 0 20px rgba(0, 220, 130, 0.5);
  white-space: nowrap;
}

.nexus-trigger-btn {
  background: #090d16;
  border: 1px solid #1e293b;
  color: #ffffff;
  padding: 0.6rem 1.1rem;
  border-radius: 999px;
  display: flex;
  align-items: center;
  gap: 0.65rem;
  cursor: pointer;
  box-shadow: 0 0 25px rgba(0, 0, 0, 0.5);
  transition: all 0.25s ease;
}

.nexus-trigger-btn:hover {
  transform: translateY(-2px);
  border-color: #00dc82;
  box-shadow: 0 0 30px rgba(0, 220, 130, 0.3);
}

.pulse-indicator {
  width: 8px;
  height: 8px;
  background: #00dc82;
  border-radius: 50%;
  box-shadow: 0 0 8px #00dc82;
  animation: pulse-glow 2s infinite;
}

@keyframes pulse-glow {
  0%, 100% { opacity: 1; transform: scale(1); }
  50% { opacity: 0.4; transform: scale(1.3); }
}

.trigger-xp-info {
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  line-height: 1.2;
}

.rank-title { font-size: 0.7rem; color: #94a3b8; font-weight: 600; }

.xp-badge {
  font-size: 0.75rem;
  font-weight: 800;
  border-bottom: 1px solid currentColor;
}

/* CHAT WINDOW */
.nexus-chat-window {
  position: absolute;
  bottom: 65px;
  right: 0;
  width: 380px;
  height: 520px;
  background: rgba(9, 13, 22, 0.96);
  backdrop-filter: blur(16px);
  border: 1px solid #1e293b;
  border-radius: 16px;
  display: flex;
  flex-direction: column;
  box-shadow: 0 20px 50px rgba(0,0,0,0.8);
  overflow: hidden;
}

.nexus-header {
  background: #020420;
  padding: 0.85rem 1.1rem;
  border-bottom: 1px solid #1e293b;
  display: flex;
  flex-direction: column;
  gap: 0.6rem;
}

.header-main { display: flex; justify-content: space-between; align-items: center; }
.status-dot { width: 6px; height: 6px; background: #00dc82; border-radius: 50%; display: inline-block; margin-right: 6px; }
.header-info strong { font-size: 0.85rem; color: #f8fafc; margin-right: 6px; }

.rank-badge-pill {
  font-size: 0.68rem;
  font-weight: 800;
  padding: 0.15rem 0.45rem;
  border-radius: 6px;
}

.close-btn { background: none; border: none; color: #64748b; font-size: 1.1rem; cursor: pointer; }
.close-btn:hover { color: #ffffff; }

/* PROGRESS BAR */
.level-progress-container { display: flex; flex-direction: column; gap: 0.25rem; }
.level-labels { display: flex; justify-content: space-between; font-size: 0.68rem; color: #64748b; }
.progress-track { height: 4px; background: #090d16; border-radius: 999px; overflow: hidden; }
.progress-fill { height: 100%; transition: width 0.3s ease; }

/* MESSAGES AREA */
.nexus-messages {
  flex: 1;
  padding: 1rem;
  overflow-y: auto;
  display: flex;
  flex-direction: column;
  gap: 0.85rem;
}

.loading-state { font-size: 0.8rem; color: #38bdf8; text-align: center; margin: auto; }

.message-bubble {
  max-width: 85%;
  padding: 0.75rem 0.9rem;
  border-radius: 12px;
  font-size: 0.83rem;
  line-height: 1.45;
}

.message-bubble.assistant {
  align-self: flex-start;
  background: #020420;
  border: 1px solid #1e293b;
  color: #cbd5e1;
}

.message-bubble.user {
  align-self: flex-end;
  background: rgba(0, 220, 130, 0.15);
  border: 1px solid rgba(0, 220, 130, 0.3);
  color: #ffffff;
}

.message-meta { display: flex; justify-content: space-between; font-size: 0.68rem; color: #64748b; margin-bottom: 0.3rem; }
.xp-reward-pill { font-size: 0.7rem; font-weight: 800; margin-top: 0.4rem; }

/* INPUT BAR */
.nexus-input-bar {
  padding: 0.75rem;
  background: #020420;
  border-top: 1px solid #1e293b;
  display: flex;
  gap: 0.5rem;
}

.nexus-input {
  flex: 1;
  background: #090d16;
  border: 1px solid #1e293b;
  color: #ffffff;
  padding: 0.6rem 0.85rem;
  border-radius: 8px;
  font-size: 0.82rem;
  outline: none;
}

.nexus-input:focus { border-color: #00dc82; }

.send-btn {
  background: #00dc82;
  border: none;
  color: #020420;
  font-weight: 900;
  padding: 0 1rem;
  border-radius: 8px;
  cursor: pointer;
  transition: opacity 0.2s;
}

.send-btn:disabled { opacity: 0.5; cursor: not-allowed; }

/* ANIMAZIONI */
.toast-anim-enter-active, .toast-anim-leave-active { transition: all 0.3s ease; }
.toast-anim-enter-from, .toast-anim-leave-to { opacity: 0; transform: translateY(10px); }

.fade-slide-enter-active, .fade-slide-leave-active { transition: all 0.25s ease; }
.fade-slide-enter-from, .fade-slide-leave-to { opacity: 0; transform: translateY(15px); }
</style>