// dkp-proprietary-plugins/dkp-pulse-nexus-pro/composables/usePulseNexus.ts
import { ref } from 'vue'

export interface ChatMessage {
  id: string
  sender: string
  role: 'user' | 'assistant' | 'system'
  text: string
  xpEarned?: number
  timestamp: string
}

const isOpen = ref(false)
const messages = ref<ChatMessage[]>([])
const userXp = ref(150)
const isLoading = ref(false)

export const usePulseNexus = () => {
  const toggleChat = () => {
    isOpen.value = !isOpen.value
    if (isOpen.value && messages.value.length === 0) {
      loadHistory()
    }
  }

  const loadHistory = async () => {
    isLoading.value = true
    try {
      const res = await $fetch('/api/nexus/history')
      if (res.success) {
        messages.value = res.messages
        userXp.value = res.xp
      }
    } catch (err) {
      console.error('Errore caricamento storico Nexus:', err)
    } finally {
      isLoading.value = false
    }
  }

  const sendNexusMessage = async (userText: string) => {
    // Aggiunta immediata optimistic UI
    const tempId = Date.now().toString()
    messages.value.push({
      id: tempId,
      sender: 'Tu',
      role: 'user',
      text: userText,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    })

    try {
      const res = await $fetch('/api/nexus/send', {
        method: 'POST',
        body: { message: userText }
      })

      if (res.success) {
        messages.value.push(res.message)
        userXp.value = res.totalXp
      }
    } catch (err) {
      console.error('Errore invio messaggio Nexus:', err)
    }
  }

  return {
    isOpen,
    messages,
    userXp,
    isLoading,
    toggleChat,
    sendNexusMessage,
    loadHistory
  }
}